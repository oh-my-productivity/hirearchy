---
name: weekly-meeting-memo
description: One short memo (decisions and action items) from one meeting notes file
inputs:
- name: notes_file
  description: File name of the meeting notes inside the notes folder, for example
    2026-10-26.md
  required: true
acceptance:
- Covers only the meeting in the given notes file.
- At most 400 words as counted by read.
- 'Has a title line and exactly two sections: Decisions and Action items.'
- The Decisions section lists every decision the team made in the notes and nothing
  that was only discussed.
- The Action items section is a markdown table with the columns Owner | Action | Due,
  one row per commitment in the notes, including informal commitments stated in prose
  and not only lines labelled ACTION.
- Every Due value is an ISO date (YYYY-MM-DD) or none; vague or relative deadlines
  are converted to a date computed from the meeting date, and the original wording
  stays in the Action text.
- Every decision and action item is traceable to the notes file; none is invented.
- 'The reviewer''s report shows every criterion met (criteria met: n of m with n =
  m), and the writer applied every required change.'
deliverable:
  description: One markdown memo per meeting, named memo-<meeting date>.md
  format: markdown
  max_words: 400
  path: /tmp/hirearchy-e3-1792594182/deliverables
budget: 15
locked: false
version: 1
defined_by: root
defined: '2026-10-21T14:57:29.629336+00:00'
created: '2026-10-21T14:57:29.629336+00:00'
---

