# Memory
Task d238 (memo 2026-10-19) reported done (reviewer 8 of 8, 0 rework). Flagged Marta-agenda ambiguity to client. Nothing pending.
Earlier: 053d done; fd70 reported blocked (root accepted memo).
Lessons: 'before X' = that date; verify weekday arithmetic; keep reserve for reviewer; fewest wakes; writer misses prose commitments - check myself first; workers return budget 0 so grant explicitly; 'demo week'/'first week' -> Due none accepted; Summary line must not embellish notes; flag weekend dates.
